export type PhoneNumberFormat = 'default' | 'national' | 'international';
